import pandas as pd
import os
print(os.path)
os.environ['R_HOME'] = 'D:\ApplicationSpace\Anaconda3\envs\py38\Lib\R'

from src.AIT_condition import AIT_test
# from rpy2.robjects import r
from pandas.core.frame import DataFrame

# import pickle

def AIT_condition(data = None):

#     data_path = os.path.join(r'example_data/linear_data_5000.csv')   # linear_data_5000.csv   # nonlinear_data_5000.csv  # Example_Data_compare_Ktest_5000.csv  # Example_Data_compare_PIM_5000.csv
#     data = pd.read_csv(data_path)
#     data = pd.read_csv(r'D:/School/BTBU/code/Imitation Learning Code/AIT_Condition-main/example_data/linear_data_5000.csv')
    # r('setwd("control_IV/controlfunctionIV-main/R")')
#     data = data

    Z = 'IV_candidate'
    A_Z = AIT_test(data, Z, relation='linear' )   # relation = 'linear' or 'nonlinear'
    # if A_Z['IV_validity']: print(f'The candidate State is valid IV!!!')
    # else: print(f'The candidate State is invalid IV!')
    return A_Z['IV_validity'],A_Z['pValue_Z']

def TCN_test(expert_trajs_data = None):
    index,valid_IV = [],[]
    for traj in expert_trajs_data:
        p_value_list = [0]
        for j in range(1, 20):
     #    for j in range(1, len(traj[0]) - 1):
            state, action, candidate_state = [], [], []
            state.append(traj[0][j:])#.reshape(-1,traj[0].shape[1])
            action.append(traj[1][j:])#.reshape(-1,traj[1].shape[1])
            candidate_state.append(traj[0][:len(traj[0])-j])#.reshape(-1,traj[0].shape[1])
          #   state = state.reshape(-1,6)
            data_dict = {"Treatment": state, "Outcome": action, "IV_candidate": candidate_state}
            AIT_data = DataFrame(data_dict,columns=["Treatment", "Outcome", "IV_candidate"])
          #   p_value_list.append(AIT_condition(data = AIT_data)[1])
            is_IV, p_value = AIT_condition(data = AIT_data)
          #   p_value_list.append([j,p_value])
            if is_IV: 
                index.append(j); valid_IV.append([j, p_value]); break
    result = max(index, key = index.count)
    return result
